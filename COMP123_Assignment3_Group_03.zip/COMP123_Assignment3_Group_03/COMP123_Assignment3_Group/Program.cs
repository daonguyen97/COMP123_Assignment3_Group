﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Name:     Huu Dao Nguyen
//Student#: 300986569
//Name:
//Student#:
//Name:
//Student#:

namespace COMP123_Assignment3_Group
{
    class Program
    {
        static void Main(string[] args)
        {
            TweetManager TM = new TweetManager();
            TweetManager.ShowAll();
            Console.Write("Enter the hashtag you want to search for: ");
            TweetManager.ShowAll(Console.ReadLine());
            TweetManager.ConvertToJson();
            Console.ReadKey();
        }
    }
}
