﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP123_Assignment3_Group
{
    class Tweet
    {
        //Fields
        private static int currentId=1;

        //Properties
        public int Id { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public string Message { get; set; }
        public string Hashtag { get; set; }

        //Methods
        public Tweet(string from,string to, string message,string hashtag) {
            Id = currentId;
            currentId++;
            From = from;
            To = to;
            Message = message;
            Hashtag = hashtag;
        }
        public override string ToString()
        {
            string Content = "From: " + From + "\tTo: " + To + "\tContent: #" + Hashtag + "  " + Message.Substring(0, Message.Length / 2)+"...";
            return Content;
        }
        public static Tweet Parse(string line) {
            string[] Content = line.Split(new char[] { '\t' });
            try
            {
                return new Tweet(Content[0], Content[1], Content[2], Content[3]);
            }
            catch {
                return new Tweet("Invalid", "Invalid", "Invalid", "Invalid");
            }
        }
    }
}
