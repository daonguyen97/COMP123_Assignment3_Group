﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.IO;

namespace COMP123_Assignment3_Group
{
    class TweetManager
    {
        //Fields
        private static Tweet[] tweets;
        private static string fileName="tweets.txt";

        //Methods
        static TweetManager()
        {
            //Read tweets data from file
            string[] TweetData = System.IO.File.ReadAllLines(fileName);
            tweets = new Tweet[TweetData.Length];
            int index = 0;
            foreach (string tweet in TweetData)
            {
                //Console.WriteLine(tweet);
                tweets.SetValue(Tweet.Parse(tweet),index);
                index++;
            }

        }
        public static void ShowAll()
        {
            //Print all tweets data
            foreach (Tweet tw in tweets)
            {
                Console.WriteLine(tw.ToString());
            }
        }
        public static void ShowAll(string hashtag)
        {
            //Print all tweets data IF tweet's hashtag equal to 'hashtag' variable
            foreach (Tweet tw in tweets)
            {
                if (tw.Hashtag==hashtag)
                Console.WriteLine(tw.ToString());
            }
        }
        public static void ConvertToJson()
        {
            //Convert tweets data to JSON file
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            StreamWriter writer = new StreamWriter("tweets.json");
            writer.Write(serializer.Serialize(tweets));
            writer.Close();
        }
    }
}
